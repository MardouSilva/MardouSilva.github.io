function multiplicacao(base){
  function multiplicador(x){
    return base * x;
  }
  return multiplicador;
}